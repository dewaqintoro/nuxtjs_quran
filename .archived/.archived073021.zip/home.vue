<template>
  <div class="text-center">
    Home
  </div>
</template>

<script>

export default {
  name: 'Home',
  // props: {
  //   surah: {
  //     type: Object,
  //     required: true,
  //   },
  // },
  setup(){
  }
}
</script>

<style lang="postcss" scoped>

</style>