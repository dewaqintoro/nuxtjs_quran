<template>
  <div>
    <Navbar :theme="myTheme" />
    <button @click="cek" class="mt-36">cek</button>
  </div>
</template>

<script>
import { ref, useContext, computed } from '@nuxtjs/composition-api'
import Navbar from '~/components/music/NavbarComp'

export default {
  name: 'MusicId',
  components: {
    Navbar
  },
  setup(props){
    
    const { route, store, app } = useContext()
    const idSurah = ref('')
    const idAyat = ref('')
    const subStore = computed(() => store.state.sub)
    const audioStore = computed(() => store.state.audio)
    const loadingAudio = computed(() => store.state.loadingAudio)

    const myTheme = {
      background: '#088b71',
      color: 'white',
      boxShadow:  '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    }

    const bgId = computed(() => {
      if(props.theme?.darktheme){
        return 'darkTheme'
      } else {
        return 'lightTheme'
      }
    })

    return {
      myTheme,
      cek
    }

    function getUnique(array){
        var uniqueArray = [];
        
        // Loop through array values
        var i = 0
        for(i; i < array.length; i++){
            if(uniqueArray.indexOf(array[i]) === -1) {
                uniqueArray.push(array[i]);
            }
        }
        return uniqueArray;
    }

    function cek(){
      var names = ["John", "Peter", "Clark", "Harry", "John", "Alice"];
      var uniqueNames = getUnique(names);
      console.log(uniqueNames);
      // console.log('audioStore',audioStore)
    }
  }
}
</script>
<style lang="postcss" scoped>
.darkTheme:hover{
  background: rgb(61, 81, 94) !important;
}
.lightTheme:hover{
  background: #f1f1f1 !important;
}

.card {
  @apply px-4 pb-4 pt-4 rounded-lg my-8;
  /* box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 10px 0 rgba(0, 0, 0, 0.15); */
  .idSurah {
    @apply items-center justify-center flex font-bold rounded-full;
    width: 40px;
    height: 40px;
  }
  .nameSurah {
    @apply px-4 w-full;
  }
}
.card:hover {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.20);
}
.surat {
  @apply text-right text-3xl mt-2;
  line-height: 4rem !important;
}
.my-audio{
  @apply mt-4;
  max-width: 100%;
  height: 35px;
}
@screen mobile {
  .surat {
    @apply text-2xl;
  }
  .idSurah {
    @apply text-sm;
    width: 30px;
    height: 30px;
  }
  .my-audio{
    max-width: 80%;
    height: 35px;
  }
}
</style>