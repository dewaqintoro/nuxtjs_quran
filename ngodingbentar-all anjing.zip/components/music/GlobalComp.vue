<template>
  <span class="flex">
    <div v-if="showIndex" class="number">
      <p>{{index+1}}</p>
      <button @click="cek">cek</button>
    </div>
    <!-- <nuxt-link :to="`music/track/`+item.key"> -->

    <!-- <nuxt-link :to="routeLink"> -->
      <!-- <div>
        <img class="img-top" :src="item.images.coverart" alt="img" />
      </div> -->
      <div class="dew-img">
        <div class="img-top">
          <!-- <img :src="item.images.coverart" alt="img" /> -->
          <img :src="getImg(item)" alt="img" />
        </div>
        <div>
          <!-- <font-awesome-icon class="centerItem" :icon="['fas', 'play']" /> -->
          <button class="centerItem focus:outline-none" @click="play" >
            <font-awesome-icon v-if="isPlay" :icon="['fas', 'pause']" />
            <font-awesome-icon v-else :icon="['fas', 'play']" />
          </button>
        </div>
      </div>
    <!-- </nuxt-link> -->
    <div class="item-title besar">
      <nuxt-link :to="baseRoute+item.key">
        <p v-if="item.title.length > 40" class="font-bold">{{item.title.substring(0, 40)}}</p>
        <p v-else class="font-bold">{{item.title}}</p>
        <p v-if="item.subtitle.length > 40">{{item.subtitle.substring(0, 40)}} ...</p>
        <p v-else>{{item.subtitle}}</p>
      </nuxt-link>
      <button class="btn-nav focus:outline-none" @click="play(item)" >
        <font-awesome-icon v-if="isPlay" :icon="['fas', 'pause']" />
        <font-awesome-icon v-else :icon="['fas', 'play']" />
      </button>
    </div>
    <div class="item-title kecil">
      <nuxt-link :to="baseRoute+item.key">
        <p v-if="item.title.length > 15" class="font-bold">{{item.title.substring(0, 15)}}</p>
        <p v-else class="font-bold">{{item.title}}</p>
        <p v-if="item.subtitle.length > 15">{{item.subtitle.substring(0, 15)}} ...</p>
        <p v-else>{{item.subtitle}}</p>
      </nuxt-link>
      <button class="btn-nav focus:outline-none" @click="play" >
        <font-awesome-icon v-if="isPlay" :icon="['fas', 'pause']" />
        <font-awesome-icon v-else :icon="['fas', 'play']" />
      </button>
    </div>
  </span>
</template>

<script>
import { ref, useContext, computed } from '@nuxtjs/composition-api'

export default {
  name: 'GlobalComp',
  props: {
    item: {
      type: Object,
      required: true,
    },
    index: {
      type: Number,
      required: true,
    },
    routeLink: {
      type: String,
      required: true,
      default: '/'
    },
    showIndex: {
      type: Boolean,
      required: false,
      default: true
    }
  },
  setup(props, {emit}){
    const { route, store, app } = useContext()
    const baseRoute = ref('')
    const idSurah = ref('')
    const isPlay = ref(false)

    cekRoute()
    return {
      isPlay,
      baseRoute,
      play,
      cek,
      getImg
    }

    function cek(){
      console.log('item', props.item)
      // if(route.value.name === 'music-artist-id')
    }

    function getImg(item){
      let str = item?.images?.coverart || 'https://res.cloudinary.com/dewaqintoro/image/upload/v1625716883/Ngodingbentar/Music/bg-white_aws30t.png'
      let stre = str.replace("{w}", "400");
      let dew = stre.replace("{h}", "400");
      return dew
    }

    function cekRoute(){
      // console.log('route', route.value)
      // if(route.value.name === 'music'){
      //   baseRoute.value = 'music/track/'
      //   baseRouteArtist.value = 'music/artist/'
      // }
      if(route.value.name === 'music-artist-id'){
        baseRoute.value = '../../music/track/'
      }
    }

    async function play(){
      if(isPlay.value === true){
        isPlay.value = false
        emit('pauseAudio')
      }else{
        emit('play', props.item)
        // emit('playAudio')
        isPlay.value = true
      }
    }

  }
}
</script>
<style lang="postcss" scoped>
.dew-img{
  position: relative;
  width: 80px;
  height: 80px;
  border-radius: 6px;
}
.centerItem {
  width: 60px;
  height: 60px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate3d(-50%,-50%,0);
}

.centerItem svg{
  width: 30px;
  height: 30px;
}

.kecil{
  display: none
}

.img-top{
  width: 80px;
  height: 80px;
}
.img-top img{
  border-radius: 10px;
}
.number{
  @apply justify-items-center my-auto mx-2;
  width: 20px;
}

.item-title{
  margin-left: 10px;
  @apply my-auto justify-items-center w-full;
}


@media (max-width: 700px) {
}
@media (max-width: 500px) {
}

@media (max-width: 450px) {

  .besar{
    display: none;
  }
  .kecil{
    display: block;
  }
}

@media (max-width: 380px) {
  .img-top{
    /* width: 100%; */
    width: 70px;
    height: 70px;
  }
}

</style>