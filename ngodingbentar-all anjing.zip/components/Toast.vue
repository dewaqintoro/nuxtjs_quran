<template>
  <div class="toast-wrapper">
    <div class="toast">
      Link Copied
    </div>
  </div>
</template>

<style>
  .toast-wrapper {
    position: fixed;
    width: 100%;
    top: 20px;
    right: 1px;
  }
  .toast {
    padding: 8px;
    color: white;
    background: #139279;
    border-radius: 5px;
    box-shadow: 1px 3px 5px rgba(0, 0, 0, 0.2);
    max-width: 300px;
    margin: 0 auto;
  }
</style>